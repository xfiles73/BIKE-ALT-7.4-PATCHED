import 'dart:async';
import 'dart:typed_data';

import 'package:bike_control/bluetooth/devices/zwift/constants.dart';
import 'package:bike_control/bluetooth/devices/zwift/zwift_clickv2.dart';
import 'package:bike_control/bluetooth/devices/zwift/zwift_clickv2_left_side.dart';
import 'package:bike_control/bluetooth/devices/zwift/zwift_clickv2_right_side.dart';
import 'package:bike_control/bluetooth/emulation/emulated_ble_platform.dart';
import 'package:bike_control/bluetooth/emulation/emulated_peripherals.dart';
import 'package:bike_control/utils/actions/base_actions.dart';
import 'package:bike_control/utils/click_v2_onboarding.dart';
import 'package:bike_control/utils/core.dart';
import 'package:bike_control/utils/keymap/apps/zwift.dart';
import 'package:fake_async/fake_async.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:prop/prop.dart';

import 'harness/test_env.dart';

/// A GET_RESPONSE for VendorDO.PAGE_DEVICE_PAIRING reporting a not-yet-synced
/// controller -- the branch of ClickLogic.processData that arms (or re-arms)
/// its 59s idle reset timer rather than firing a RESET immediately.
Uint8List _unresolvedPairingPageResponse() {
  final page = DevicePairingDataPage(pairingStatus: ControllerSyncStatus.NOT_CONNECTED.value);
  final response = GetResponse(dataObjectId: VendorDO.PAGE_DEVICE_PAIRING.value, dataObjectData: page.writeToBuffer());
  return Uint8List.fromList([Opcode.GET_RESPONSE.value, ...response.writeToBuffer()]);
}

/// The onboarding gate through the REAL Connection class: a discovered Click
/// V2 must reach the device list but open no BLE connection until the rider
/// has picked an unlock mode.
Future<void> main() async {
  final env = await IntegrationEnv.setUp();

  core.connection.initialize();

  setUp(() async {
    await env.resetState();
    final stubActions = StubActions();
    stubActions.supportedApp = Zwift();
    core.actionHandler = stubActions;
  });

  tearDown(() async {
    await env.resetConnection();
  });

  test('a pending Click V2 is listed but never connected', () async {
    await core.settings.setClickV2OnboardingDone(false);
    await core.settings.setUnlockWithZwift(false);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    final right = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_RIGHT_SIDE);
    env.ble.addPeripheral(left);
    env.ble.addPeripheral(right);

    await core.connection.performScanning();

    await IntegrationEnv.waitFor(
      () =>
          core.connection.devices.whereType<ZwiftClickV2LeftSide>().isNotEmpty &&
          core.connection.devices.whereType<ZwiftClickV2RightSide>().isNotEmpty,
      description: 'both Click V2 sides to appear in the device list',
    );

    final leftDevice = core.connection.devices.whereType<ZwiftClickV2LeftSide>().first;
    final rightDevice = core.connection.devices.whereType<ZwiftClickV2RightSide>().first;

    expect(leftDevice.shouldAutoConnect, isFalse);
    expect(rightDevice.shouldAutoConnect, isFalse);
    expect(leftDevice.isConnected, isFalse);
    expect(rightDevice.isConnected, isFalse);

    // The gate is about the transport, not just the flag: no BLE link was
    // opened and no handshake ran.
    expect(left.isConnected, isFalse);
    expect(right.isConnected, isFalse);
    expect(left.subscriptions, isEmpty);
    expect(right.subscriptions, isEmpty);
    expect(left.writes, isEmpty);
    expect(right.writes, isEmpty);
  });

  test('a Click V2 connects normally once onboarding is done', () async {
    await core.settings.setClickV2OnboardingDone(true);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    env.ble.addPeripheral(left);

    await core.connection.performScanning();

    final device = await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2LeftSide>().isNotEmpty,
      description: 'the Click V2 left side to appear',
    ).then((_) => core.connection.devices.whereType<ZwiftClickV2LeftSide>().first);

    await IntegrationEnv.waitFor(
      () => device.isConnected,
      description: 'the Click V2 left side to connect',
    );

    expect(left.isConnected, isTrue);
  });

  test('choosing right-side-only writes settings and connects the right side', () async {
    await core.settings.setClickV2OnboardingDone(false);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(true);

    final right = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_RIGHT_SIDE);
    env.ble.addPeripheral(right);
    await core.connection.performScanning();
    await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2RightSide>().isNotEmpty,
      description: 'the Click V2 right side to appear',
    );

    expect(ClickV2Onboarding.pendingDevices, isNotEmpty);

    await ClickV2Onboarding.chooseRightSideOnly();

    expect(core.settings.getUnlockWithZwift(), isFalse);
    expect(core.settings.getClickV2RightSideOnly(), isTrue);
    expect(core.settings.getUseNewUnlockMethod(), isTrue);
    expect(core.settings.getClickV2OnboardingDone(), isTrue);
    expect(ClickV2Onboarding.isPending, isFalse);

    await IntegrationEnv.waitFor(
      () => right.isConnected,
      description: 'the Click V2 right side to connect after the choice',
    );
  });

  // The whole point of the mode: the locked puck stays out. A plain disconnect
  // is not enough -- the active scan hands it straight back, and it reappears
  // in every controller list (the home chain included) as an entry stuck on
  // "connecting". Ignoring is the mechanism the scan filter already honours.
  test('right-side-only puts the left side on the ignored list', () async {
    await core.settings.setClickV2OnboardingDone(false);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(true);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    env.ble.addPeripheral(left);
    await core.connection.performScanning();
    await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2LeftSide>().isNotEmpty,
      description: 'the Click V2 left side to appear',
    );

    await ClickV2Onboarding.chooseRightSideOnly();

    expect(
      core.settings.getIgnoredDevices().map((d) => d.name),
      contains(ZwiftClickV2LeftSide.label),
    );
    // Gone from the lists, and it stays gone: a further scan must not quietly
    // hand it back.
    expect(core.connection.devices.whereType<ZwiftClickV2LeftSide>(), isEmpty);
    await core.connection.performScanning();
    expect(core.connection.devices.whereType<ZwiftClickV2LeftSide>(), isEmpty);
    expect(core.connection.controllerDevices.whereType<ZwiftClickV2LeftSide>(), isEmpty);
  });

  // Reported from a device: turning "use new unlock method" ON from the legacy
  // unified controller connected only the LEFT puck -- the one that needs
  // unlocking -- which is the setup the switch is meant to move the rider off.
  test('turning the split representation on ignores the left puck', () async {
    await core.settings.setClickV2OnboardingDone(true);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(false);

    // Legacy: the unified ZwiftClickV2 is built from the LEFT puck's advert.
    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    env.ble.addPeripheral(left);
    await core.connection.performScanning();
    await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2>().isNotEmpty,
      description: 'the legacy unified Click V2 to appear',
    );

    // What NewUnlockMethodToggle does when switched on.
    await core.settings.setUseNewUnlockMethod(true);
    await ClickV2Onboarding.chooseRightSideOnly();

    expect(core.settings.getClickV2RightSideOnly(), isTrue);
    // The unified controller is the left puck under another class, so it has
    // to land on the ignored list under ITS name.
    expect(
      core.settings.getIgnoredDevices().map((d) => d.name),
      contains(ZwiftClickV2.label),
    );
    expect(core.connection.devices.whereType<ZwiftClickV2>(), isEmpty);
  });

  // Reported from a device: right-side-only, then "use new unlock method" off,
  // left the rider with no Click at all and the chain showing its empty
  // "Controller" placeholder. In the legacy representation the LEFT puck is
  // what becomes the unified ZwiftClickV2 and the right puck builds nothing --
  // so an ignored left side means nothing can be built.
  test('turning the split representation off un-ignores the left side', () async {
    await core.settings.setClickV2OnboardingDone(false);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(true);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    env.ble.addPeripheral(left);
    await core.connection.performScanning();
    await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2LeftSide>().isNotEmpty,
      description: 'the Click V2 left side to appear',
    );

    await ClickV2Onboarding.chooseRightSideOnly();
    expect(
      core.settings.getIgnoredDevices().map((d) => d.name),
      contains(ZwiftClickV2LeftSide.label),
    );

    // What NewUnlockMethodToggle does when switched off.
    await core.settings.setUseNewUnlockMethod(false);
    await core.settings.setClickV2RightSideOnly(false);
    await ClickV2Onboarding.restoreLeftSides();

    expect(core.settings.getIgnoredDevices(), isEmpty);
    // And the puck is actually back -- as the legacy unified controller, since
    // the split representation is off now.
    await IntegrationEnv.waitFor(
      // Not just "a ZwiftClickV2": ZwiftClickV2LeftSide extends it, so that
      // alone would also pass on a stale split-side object left behind.
      () => core.connection.devices.whereType<ZwiftClickV2>().any((d) => d is! ZwiftClickV2LeftSide),
      description: 'the legacy unified Click V2 to be rebuilt from the left puck',
    );
  });

  // Otherwise the rider who picked right-side-only first, then changed their
  // mind, picks the both-controllers option and still only ever gets one.
  test('unlock-with-Zwift takes the left side back off the ignored list', () async {
    await core.settings.setClickV2OnboardingDone(false);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(true);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    env.ble.addPeripheral(left);
    await core.connection.performScanning();
    await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2LeftSide>().isNotEmpty,
      description: 'the Click V2 left side to appear',
    );

    await ClickV2Onboarding.chooseRightSideOnly();
    expect(core.settings.getIgnoredDevices(), isNotEmpty);

    await ClickV2Onboarding.chooseUnlockWithZwift();

    expect(
      core.settings.getIgnoredDevices().map((d) => d.name),
      isNot(contains(ZwiftClickV2LeftSide.label)),
    );
    await IntegrationEnv.waitFor(
      // As the unified controller: this mode is "both pucks as one device", so
      // it switches the split representation off too. Not just "a
      // ZwiftClickV2" — ZwiftClickV2LeftSide extends it, so that alone would
      // also pass on a stale split-side object left behind.
      () => core.connection.devices.whereType<ZwiftClickV2>().any((d) => d is! ZwiftClickV2LeftSide),
      description: 'the left puck to come back as the unified Click V2',
    );
  });

  // Reported from a device: picking unlock-with-Zwift on the right puck's card
  // updated the mode but left the separate right-side entry connected, with no
  // way back to the joined controller — the switch that used to do it was the
  // only thing that could turn the split representation off.
  test('unlock-with-Zwift folds the split entries back into the unified controller', () async {
    await core.settings.setClickV2OnboardingDone(true);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(true);
    await core.settings.setClickV2RightSideOnly(true);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    final right = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_RIGHT_SIDE);
    env.ble.addPeripheral(left);
    env.ble.addPeripheral(right);
    await core.connection.performScanning();
    await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2RightSide>().isNotEmpty,
      description: 'the Click V2 right side to appear',
    );

    await ClickV2Onboarding.chooseUnlockWithZwift();

    expect(core.settings.getUseNewUnlockMethod(), isFalse);
    expect(core.settings.getClickV2RightSideOnly(), isFalse);
    await IntegrationEnv.waitFor(
      () =>
          core.connection.devices.whereType<ZwiftClickV2>().any((d) => d is! ZwiftClickV2LeftSide) &&
          core.connection.devices.whereType<ZwiftClickV2RightSide>().isEmpty,
      description: 'the unified Click V2 to replace the separate right-side entry',
    );
  });

  test('choosing unlock-with-Zwift writes settings and connects the pending sides', () async {
    await core.settings.setClickV2OnboardingDone(false);
    await core.settings.setUnlockWithZwift(false);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    env.ble.addPeripheral(left);
    await core.connection.performScanning();
    await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2LeftSide>().isNotEmpty,
      description: 'the Click V2 left side to appear',
    );

    await ClickV2Onboarding.chooseUnlockWithZwift();

    expect(core.settings.getUnlockWithZwift(), isTrue);
    expect(core.settings.getClickV2OnboardingDone(), isTrue);
    expect(ClickV2Onboarding.isPending, isFalse);

    await IntegrationEnv.waitFor(
      () => left.isConnected,
      description: 'the Click V2 left side to connect after the choice',
    );
  });

  test('right-side-only turns the split representation back on when it was off', () async {
    await core.settings.setClickV2OnboardingDone(false);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(false);

    // The right side does not exist as its own device in the legacy unified
    // representation, so this mode cannot be honoured without flipping it on.
    await ClickV2Onboarding.chooseRightSideOnly();

    expect(core.settings.getUseNewUnlockMethod(), isTrue);
  });

  // Reported from Windows: right-side-only picked while on the legacy unified
  // controller took the early "turn split back on" route, which never ignored
  // the left puck. The rescan rebuilt it as a split left side that connected
  // and ran the restart loop beside the right side -- a reboot every few
  // seconds, and the app froze after a few of them.
  test('right-side-only from the legacy representation ignores the left puck', () async {
    await core.settings.setClickV2OnboardingDone(true);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(false);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    env.ble.addPeripheral(left);
    await core.connection.performScanning();
    final unified = await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2>().isNotEmpty,
      description: 'the legacy unified Click V2 to appear',
    ).then((_) => core.connection.devices.whereType<ZwiftClickV2>().first);
    await IntegrationEnv.waitFor(() => unified.isConnected, description: 'the unified Click V2 to connect');

    await ClickV2Onboarding.chooseRightSideOnly();

    expect(
      core.settings.getIgnoredDevices().map((d) => d.name),
      contains(ZwiftClickV2.label),
    );
    await IntegrationEnv.waitFor(() => !left.isConnected, description: 'the left puck to be dropped');
    await core.connection.performScanning();
    expect(core.connection.devices.whereType<ZwiftClickV2LeftSide>(), isEmpty);
    expect(left.isConnected, isFalse);
  });

  // Riders already stuck in that state on 7.3.0: right-side-only is on, but
  // their left puck never made it onto the ignored list.
  test('right-side-only never connects a left puck that is not ignored', () async {
    await core.settings.setClickV2OnboardingDone(true);
    await core.settings.setUnlockWithZwift(false);
    await core.settings.setUseNewUnlockMethod(true);
    await core.settings.setClickV2RightSideOnly(true);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    final right = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_RIGHT_SIDE);
    env.ble.addPeripheral(left);
    env.ble.addPeripheral(right);
    await core.connection.performScanning();

    await IntegrationEnv.waitFor(() => right.isConnected, description: 'the right side to connect');
    expect(left.isConnected, isFalse);
    expect(left.writes, isEmpty);
  });

  // "Set up again" routes through the same chooseRightSideOnly /
  // chooseUnlockWithZwift entry points as first-time onboarding, but reaches
  // them with the left side ALREADY CONNECTED -- a case first-time onboarding
  // never hits (a pending device is by definition disconnected). Switching to
  // right-side-only there has to actually take the left side down, not just
  // write the setting and leave a live link that the new mode says is not
  // part of the setup.
  test('"Set up again" -> right side only drops an already-connected left side', () async {
    // Onboarding already done and settled on Zwift mode -- i.e. the rider is
    // re-visiting the explainer via "Set up again", not doing first-time
    // onboarding.
    await core.settings.setClickV2OnboardingDone(true);
    await core.settings.setUnlockWithZwift(true);
    await core.settings.setClickV2RightSideOnly(false);

    final left = buildZwiftClickV2(sideCode: ZwiftConstants.CLICK_V2_LEFT_SIDE);
    env.ble.addPeripheral(left);
    await core.connection.performScanning();

    final device = await IntegrationEnv.waitFor(
      () => core.connection.devices.whereType<ZwiftClickV2LeftSide>().isNotEmpty,
      description: 'the Click V2 left side to appear',
    ).then((_) => core.connection.devices.whereType<ZwiftClickV2LeftSide>().first);

    await IntegrationEnv.waitFor(
      () => device.isConnected,
      description: 'the Click V2 left side to connect',
    );

    await ClickV2Onboarding.chooseRightSideOnly();

    expect(core.settings.getUnlockWithZwift(), isFalse);
    expect(core.settings.getClickV2RightSideOnly(), isTrue);

    await IntegrationEnv.waitFor(
      () => !left.isConnected,
      description: 'the already-connected left side to be dropped by the mode switch',
    );

    // And it stays down: ignored, so the next scan does not bring it back.
    await core.connection.performScanning();
    expect(left.isConnected, isFalse);
    expect(
      core.settings.getIgnoredDevices().map((d) => d.name),
      contains(ZwiftClickV2LeftSide.label),
    );
  });

  // FINDING 1 (reset-timer half). ClickLogic._resetTimer is private static
  // state -- a test in this file cannot read "was it cancelled" directly.
  // What IS observable is its side effect: left uncancelled, it fires a
  // RESET write 59s later. The next two tests use fake_async to fast-forward
  // past that window without a real 59s wait, and assert on that write's
  // presence/absence. This proves the practical consequence FINDING 1 cares
  // about (no spurious restart right after picking Zwift mode) but NOT that
  // `ClickLogic.resetTimer()` specifically is what did it, as opposed to some
  // other change that coincidentally also suppresses the write -- that
  // distinction is not observable from outside ClickLogic.
  test('sanity control: an unresolved pairing response arms a reset timer that fires when nothing cancels it', () {
    fakeAsync((async) {
      final peripheral = FakePeripheral(deviceId: 'reset-timer-control', name: 'Zwift Click');
      env.ble.addPeripheral(peripheral);

      ClickLogic.processData(_unresolvedPairingPageResponse(), deviceId: peripheral.deviceId, services: const []);

      async.elapse(const Duration(seconds: 60));

      expect(
        peripheral.writes.any((w) => w.value.isNotEmpty && w.value.first == Opcode.RESET.value),
        isTrue,
        reason: 'the armed 59s idle timer should have fired a RESET with nothing to cancel it',
      );
    });
  });

  test('"Set up again" -> unlock with Zwift cancels a live ClickLogic reset timer', () {
    fakeAsync((async) {
      final peripheral = FakePeripheral(deviceId: 'reset-timer-cancel', name: 'Zwift Click');
      env.ble.addPeripheral(peripheral);

      ClickLogic.processData(_unresolvedPairingPageResponse(), deviceId: peripheral.deviceId, services: const []);

      unawaited(ClickV2Onboarding.chooseUnlockWithZwift());
      async.flushMicrotasks();

      async.elapse(const Duration(seconds: 60));

      expect(
        peripheral.writes.any((w) => w.value.isNotEmpty && w.value.first == Opcode.RESET.value),
        isFalse,
        reason: 'chooseUnlockWithZwift should have cancelled the pending reset timer before it fired',
      );
    });
  });
}
